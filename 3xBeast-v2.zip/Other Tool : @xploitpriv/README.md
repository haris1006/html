<h1>3xBeast v2</h1>
<p>
  <a href="https://github.com/3xPr1nc3/3xBeast-v2"><img src="https://img.shields.io/badge/3xBeast-v2.1-red.svg" alt="Version" data-canonical-src="https://img.shields.io/badge/3xBeast-v2.1-red.svg" style="max-width:100%;"></a>
  <a href="https://github.com/3xPr1nc3/3xBeast-v2"><img src="https://img.shields.io/badge/Release-Stable-orange.svg" alt="Release" data-canonical-src="https://img.shields.io/badge/Release-Stable-orange.svg" style="max-width:100%;"></a>
  <a href="https://github.com/3xPr1nc3/3xBeast-v2"><img src="https://img.shields.io/badge/Supported%20OS-Windows%20%2F%20Linux-blue.svg" alt="Supported" data-canonical-src="https://img.shields.io/badge/Supported%20OS-Windows%20%2F%20Linux-blue.svg" style="max-width:100%;"></a>
  <a href="https://github.com/3xPr1nc3/3xBeast-v2"><img src="https://img.shields.io/badge/Auto%20Update-Yes-green.svg" alt="Update" data-canonical-src="https://img.shields.io/badge/Auto%20Update-Yes-green.svg" style="max-width:100%;"></a>
  <a href="https://github.com/3xPr1nc3/3xBeast-v2"><img src="https://img.shields.io/badge/ICQ-744324366-red.svg" alt="Update" data-canonical-src="https://img.shields.io/badge/ICQ-744324366-red.svg" style="max-width:100%;"></a>
</p>
<p>3xBeast v2 is compatible only with this wso -> https://pastebin.com/raw/Ds35ij44</p>
<p>Note: Do not delete the temp folder!</p>
<img src="https://raw.githubusercontent.com/3xPr1nc3/3xBeast-v2/master/3xBeastv2.png">
